# `road_topology_slices.py`
- 主入口脚本。只负责串联步骤，不实现底层算法细节。
- 输入全局道路 mask（`png` 或 `npz`），执行道路拓扑切片规划（不含 LAS 导出）。
- 所有默认参数已内置为当前常用配置，VS Code `launch` 仅需传入输入/输出路径。
- 依赖：`shapely`、`scipy`、`scikit-image`、`scikit-learn`、`opencv-python`

# `scene_slice_utils.py`
- 所有算法函数与可视化函数都在这个文件中。
- `road_topology_slices.py` 只做主流程调度，具体实现都通过本工具文件调用。

## 主入口执行流程（`road_topology_slices.py`）
1. **Step 1：拓扑分辨率下采样**  
将原始道路 mask 从源分辨率映射到拓扑分辨率（用于后续规划），降低噪声与伪分支。

2. **Step 2：Mask 清理**  
对下采样后的 mask 做闭运算、去小连通域、填小孔洞。

3. **Step 3：骨架化与剪枝**  
将道路面压成单像素骨架，再删除短刺分支。

4. **Step 4：骨架建图**  
在骨架上按 8 邻域构图：提取候选路口、端点、关键点路径，并生成图边。

5. **Step 5：路口合并与节点重整**  
先做近邻路口合并（保留一个路口节点并继承连接关系），再对所有节点按长分支数量重整：  
- `>=3` 长分支：路口  
- `=2` 长分支：该点不作为节点，合并两条长边  
- `=1` 长分支：端点  
- `=0` 长分支：删除

6. **Step 6：路口半径估计（距离变换）**  
计算距离变换 `D`，沿 incident 边采样局部半路宽，得到每个路口的半径估计。

7. **Step 7：切片几何生成**  
生成路口矩形切片与路段切片（方头 buffer）；路段端点支持外扩，方向由该分区骨架整体方向估计。

8. **Step 8：可视化与结果导出**  
输出黑底过程图（清理、骨架、建图）与最终中心线分区叠加图，同时导出节点/边表、切片几何和 summary 数据。

## 输出文件
- `step3_clean_mask_black.png`：清理后 mask（黑底）
- `step4_skeleton_black.png`：骨架（加粗）+ 端点强调（黑底）
- `step5_graph_black.png`：建图结果（粗边 + 节点 + 图例，黑底）
- `step8_partitions_centerline_overlay.png`：原图上分区中心线与分区编号叠加图
- `nodes.csv`：节点表（类型、坐标、度）
- `edges.csv`：边表（端点、长度）
- `slice_polygons.json`：切片多边形 WKT
- `pipeline_summary.npz`：中间数组与统计（包含节点/边数量、分区数量、路口合并数量等）

## 代码使用流程
1. **准备输入**
- 准备全局道路 mask（推荐 `all_prompts_global_instances.npz`）。

2. **运行主脚本**
- 命令行：
```bash
python road_topology_slices.py \
  all_prompts_global_instances.npz \
  road_slice_plan
```

